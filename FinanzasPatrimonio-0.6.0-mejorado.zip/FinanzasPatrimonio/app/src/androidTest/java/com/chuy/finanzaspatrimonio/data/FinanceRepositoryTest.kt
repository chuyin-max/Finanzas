package com.chuy.finanzaspatrimonio.data

import android.content.Context
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import androidx.test.ext.junit.runners.AndroidJUnit4
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith

@RunWith(AndroidJUnit4::class)
class FinanceRepositoryTest {
    private lateinit var db: AppDatabase
    private lateinit var repository: FinanceRepository

    @Before fun setup() {
        val context = ApplicationProvider.getApplicationContext<Context>()
        db = Room.inMemoryDatabaseBuilder(context, AppDatabase::class.java).allowMainThreadQueries().build()
        repository = FinanceRepository(db)
    }

    @After fun close() { db.close() }

    @Test fun transferMovesMoneyWithoutChangingCombinedBalance() = runBlocking {
        repository.createWallet("Efectivo", "CASH", 100_00)
        repository.createWallet("Banco", "BANK", 25_00)
        val wallets = repository.wallets.first()
        val cash = wallets.first { it.name == "Efectivo" }
        val bank = wallets.first { it.name == "Banco" }

        repository.transfer("Ahorro", 40_00, cash.id, bank.id)

        val balances = repository.walletBalances.first().associateBy { it.id }
        assertEquals(60_00L, balances.getValue(cash.id).balance)
        assertEquals(65_00L, balances.getValue(bank.id).balance)
        assertEquals(125_00L, balances.values.sumOf { it.balance })
        val entries = repository.transactions.first()
        assertEquals(2, entries.size)
        assertEquals(setOf("TRANSFER_OUT", "TRANSFER_IN"), entries.map { it.type }.toSet())
    }

    @Test fun incomeAndExpenseUpdateOnlyTheirWallet() = runBlocking {
        repository.createWallet("Cuenta", "CASH", 100_00)
        val wallet = repository.wallets.first().single()
        repository.addIncome("Pago", 50_00, wallet.id, "Trabajo")
        repository.addExpense("Comida", 20_00, wallet.id, "Alimentos")
        assertEquals(130_00L, repository.walletBalances.first().single().balance)
    }

    @Test fun journalEntriesAreBalancedForOpeningIncomeExpenseAndTransfer() = runBlocking {
        repository.createWallet("Efectivo", "CASH", 100_00)
        repository.createWallet("Banco", "BANK", 0)
        val wallets = repository.wallets.first().associateBy { it.name }
        repository.addIncome("Pago", 50_00, wallets.getValue("Efectivo").id, "Trabajo")
        repository.addExpense("Comida", 20_00, wallets.getValue("Efectivo").id, "Alimentos")
        repository.transfer("Ahorro", 10_00, wallets.getValue("Efectivo").id, wallets.getValue("Banco").id)

        val entries = db.financeDao().observeJournalEntriesForTest()
        assertEquals(4, entries.size) // apertura, ingreso, egreso y transferencia
        entries.forEach { assertEquals(true, db.financeDao().isEntryBalanced(it.id)) }
    }

    @Test fun transfersDoNotCountAsIncomeOrExpense() = runBlocking {
        repository.createWallet("Origen", "CASH", 100_00)
        repository.createWallet("Destino", "BANK", 0)
        val wallets = repository.wallets.first().associateBy { it.name }
        repository.transfer("Movimiento interno", 25_00, wallets.getValue("Origen").id, wallets.getValue("Destino").id)
        val summary = repository.getFinancialSummary()
        assertEquals(0L, summary.income)
        assertEquals(0L, summary.expenses)
        assertEquals(100_00L, summary.cash)
        assertEquals(100_00L, summary.netWorth)
    }

    @Test fun inventoryPurchasesAndPartialSalesUpdateCashStockAndProfit() = runBlocking {
        repository.createWallet("Efectivo", "CASH", 100_000)
        val wallet = repository.wallets.first().single()
        repository.createProduct("Laptop")
        val product = repository.products.first().single()
        repository.purchaseProduct(product.id, 2_000, 10_000, wallet.id)
        repository.purchaseProduct(product.id, 2_000, 14_000, wallet.id)
        val afterPurchases = repository.products.first().single()
        assertEquals(4_000L, afterPurchases.quantityMilli)
        assertEquals(6_000L, afterPurchases.averageUnitCost)
        repository.sellProduct(product.id, 1_000, 8_000, wallet.id)
        val afterSale = repository.products.first().single()
        assertEquals(3_000L, afterSale.quantityMilli)
        val summary = repository.getFinancialSummary()
        assertEquals(84_000L, summary.cash)
        assertEquals(18_000L, summary.inventory)
        assertEquals(2_000L, summary.salesProfit)
        assertEquals(102_000L, summary.netWorth)
        db.financeDao().observeJournalEntriesForTest().forEach { assertEquals(true, db.financeDao().isEntryBalanced(it.id)) }
    }

    @Test fun debtPaymentSeparatesCapitalAndInterest() = runBlocking {
        repository.createWallet("Banco", "BANK", 20_000)
        val wallet = repository.wallets.first().single()
        repository.createLiability("Préstamo", 10_000)
        val debt = repository.liabilities.first().single()
        repository.payLiability(debt.id, wallet.id, 4_000, 500)
        val updated = repository.liabilities.first().single()
        assertEquals(6_000L, updated.outstandingAmount)
        assertEquals(15_500L, repository.walletBalances.first().single().balance)
        assertEquals(9_500L, repository.getFinancialSummary().netWorth)
        db.financeDao().observeJournalEntriesForTest().forEach { assertEquals(true, db.financeDao().isEntryBalanced(it.id)) }
    }

    @Test fun exportsCsvAndJsonSnapshots() = runBlocking {
        repository.createWallet("Efectivo", "CASH", 5_000)
        val wallet = repository.wallets.first().single()
        repository.addIncome("Pago", 1_000, wallet.id)
        val csv = repository.exportCsv()
        val json = repository.exportJson()
        assertEquals(true, csv.contains("descripcion"))
        assertEquals(true, csv.contains("Pago"))
        assertEquals(true, json.contains("FinanzasPatrimonio"))
        assertEquals(true, json.contains("transactions"))
        assertEquals(true, json.contains("wallets"))
    }

    @Test fun expenseCannotOverdrawAndDoesNotPersist() = runBlocking {
        repository.createWallet("Cuenta", "CASH", 10_00)
        val wallet = repository.wallets.first().single()
        try {
            repository.addExpense("Compra", 11_00, wallet.id, null)
            throw AssertionError("Se esperaba saldo insuficiente")
        } catch (expected: IllegalArgumentException) {
            assertEquals(10_00L, repository.walletBalances.first().single().balance)
            assertEquals(0, repository.transactions.first().size)
        }
    }

    @Test fun voidIncomeRemovesItFromBalance() = runBlocking {
        repository.createWallet("Cuenta", "CASH", 10_00)
        val wallet = repository.wallets.first().single()
        repository.addIncome("Pago", 50_00, wallet.id)
        val tx = repository.transactions.first().single()
        repository.voidTransaction(tx.id)
        assertEquals(10_00L, repository.walletBalances.first().single().balance)
        assertEquals(0, repository.transactions.first().size)
    }

    @Test fun backupRoundTripRestoresAllData() = runBlocking {
        repository.createWallet("Efectivo", "CASH", 100_000)
        val wallet = repository.wallets.first().single()
        repository.createProduct("Laptop")
        val product = repository.products.first().single()
        repository.purchaseProduct(product.id, 2_000, 10_000, wallet.id)
        repository.sellProduct(product.id, 1_000, 8_000, wallet.id, 500)
        repository.createLiability("Préstamo", 10_000)
        val before = repository.getFinancialSummary()
        val json = repository.exportJson()
        repository.addExpense("Extra", 1_000, wallet.id)
        repository.importJson(json)
        assertEquals(before, repository.getFinancialSummary())
        db.financeDao().observeJournalEntriesForTest().forEach { assertEquals(true, db.financeDao().isEntryBalanced(it.id)) }
    }

    @Test fun invalidBackupDoesNotTouchData() = runBlocking {
        repository.createWallet("Efectivo", "CASH", 5_000)
        try {
            repository.importJson("{\"format\":\"otro\"}")
            throw AssertionError("Se esperaba rechazo")
        } catch (expected: IllegalArgumentException) {
            assertEquals(5_000L, repository.getFinancialSummary().cash)
        }
    }
}
