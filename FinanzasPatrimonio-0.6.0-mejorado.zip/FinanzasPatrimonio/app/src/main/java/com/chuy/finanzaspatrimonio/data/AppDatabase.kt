package com.chuy.finanzaspatrimonio.data

import androidx.room.Database
import androidx.room.RoomDatabase

@Database(
    entities = [
        WalletEntity::class, TransactionEntity::class, LedgerAccountEntity::class,
        JournalEntryEntity::class, JournalLineEntity::class, ProductEntity::class,
        AssetEntity::class, LiabilityEntity::class, SaleEntity::class
    ],
    version = 3,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun financeDao(): FinanceDao
}
