package com.chuy.finanzaspatrimonio.data

import androidx.room.withTransaction
import java.util.UUID
import org.json.JSONArray
import org.json.JSONObject
import kotlinx.coroutines.flow.Flow

data class FinancialSummary(
    val cash: Long, val liabilities: Long, val netWorth: Long,
    val income: Long, val expenses: Long,
    val inventory: Long = 0L, val salesProfit: Long = 0L
)

class FinanceRepository(private val db: AppDatabase) {
    private val dao = db.financeDao()
    val wallets: Flow<List<WalletEntity>> = dao.observeWallets()
    val walletBalances: Flow<List<WalletBalance>> = dao.observeWalletBalances()
    val transactions: Flow<List<TransactionEntity>> = dao.observeRecentTransactions()
    val products: Flow<List<ProductEntity>> = dao.observeProducts()
    val liabilities: Flow<List<LiabilityEntity>> = dao.observeLiabilities()
    val sales: Flow<List<SaleEntity>> = dao.observeSales()

    suspend fun exportCsv(): String {
        val rows = dao.allTransactionsForBackup()
        fun esc(value: String) = "\"" + value.replace("\"", "\"\"") + "\""
        return buildString {
            appendLine("id,fecha,tipo,descripcion,importe_centavos,cuenta_id,estado")
            rows.forEach { appendLine(listOf(it.id.toString(),it.date.toString(),it.type,esc(it.description),it.amount.toString(),it.walletId.toString(),it.status).joinToString(",")) }
        }
    }

    suspend fun exportJson(): String = db.withTransaction {
        val root = JSONObject().put("format", "FinanzasPatrimonio").put("formatVersion", 2).put("exportedAt", System.currentTimeMillis())
        root.put("wallets", JSONArray().apply { dao.allWalletsForBackup().forEach { w -> put(JSONObject().put("id",w.id).put("name",w.name).put("type",w.type).put("currency",w.currency).put("openingBalance",w.openingBalance).put("createdAt",w.createdAt).put("active",w.active)) } })
        root.put("transactions", JSONArray().apply { dao.allTransactionsForBackup().forEach { t -> put(JSONObject().put("id",t.id).put("description",t.description).put("amount",t.amount).put("type",t.type).put("walletId",t.walletId).put("category",t.category ?: JSONObject.NULL).put("date",t.date).put("status",t.status).put("transferGroupId",t.transferGroupId ?: JSONObject.NULL)) } })
        root.put("products", JSONArray().apply { dao.allProductsForBackup().forEach { p -> put(JSONObject().put("id",p.id).put("name",p.name).put("description",p.description).put("quantityMilli",p.quantityMilli).put("averageUnitCost",p.averageUnitCost).put("suggestedSalePrice",p.suggestedSalePrice).put("createdAt",p.createdAt).put("active",p.active)) } })
        root.put("sales", JSONArray().apply { dao.allSalesForBackup().forEach { sale -> put(JSONObject().put("id",sale.id).put("transactionId",sale.transactionId).put("productId",sale.productId ?: JSONObject.NULL).put("productName",sale.productName).put("description",sale.description).put("quantityMilli",sale.quantityMilli).put("acquisitionCost",sale.acquisitionCost).put("saleAmount",sale.saleAmount).put("additionalCosts",sale.additionalCosts).put("saleDate",sale.saleDate)) } })
        root.put("liabilities", JSONArray().apply { dao.allLiabilitiesForBackup().forEach { d -> put(JSONObject().put("id",d.id).put("name",d.name).put("initialAmount",d.initialAmount).put("outstandingAmount",d.outstandingAmount).put("interestRateBasisPoints",d.interestRateBasisPoints ?: JSONObject.NULL).put("status",d.status).put("dueDate",d.dueDate ?: JSONObject.NULL)) } })
        root.put("ledgerAccounts", JSONArray().apply { dao.allLedgerForBackup().forEach { a -> put(JSONObject().put("id",a.id).put("code",a.code).put("name",a.name).put("type",a.type)) } })
        root.put("journalEntries", JSONArray().apply { dao.allJournalEntriesForBackup().forEach { e -> put(JSONObject().put("id",e.id).put("transactionId",e.transactionId ?: JSONObject.NULL).put("memo",e.memo).put("date",e.date).put("status",e.status)) } })
        root.put("journalLines", JSONArray().apply { dao.allJournalLinesForBackup().forEach { l -> put(JSONObject().put("id",l.id).put("entryId",l.entryId).put("accountId",l.accountId).put("debit",l.debit).put("credit",l.credit)) } })
        root.toString(2)
    }

    private fun JSONObject.longOrNull(key: String): Long? = if (!has(key) || isNull(key)) null else getLong(key)
    private fun JSONObject.stringOrNull(key: String): String? = if (!has(key) || isNull(key)) null else getString(key)
    private fun <T> JSONArray?.mapObjects(block: (JSONObject) -> T): List<T> {
        val array = this ?: return emptyList()
        return List(array.length()) { block(array.getJSONObject(it)) }
    }

    /** Restaura un respaldo JSON reemplazando TODOS los datos actuales. Todo o nada: si algo falla, no cambia nada. */
    suspend fun importJson(text: String) {
        val root = try { JSONObject(text) } catch (e: Exception) { throw IllegalArgumentException("El archivo no es un respaldo válido.") }
        require(root.optString("format") == "FinanzasPatrimonio") { "El archivo no es un respaldo de FinanzasPatrimonio." }
        require(root.optInt("formatVersion", 0) in 1..2) { "Versión de respaldo no compatible." }
        val parsed = try {
            val wallets = root.optJSONArray("wallets").mapObjects { WalletEntity(it.getLong("id"), it.getString("name"), it.getString("type"), it.getString("currency"), it.getLong("openingBalance"), it.getLong("createdAt"), it.getBoolean("active")) }
            val txs = root.optJSONArray("transactions").mapObjects { TransactionEntity(it.getLong("id"), it.getString("description"), it.getLong("amount"), it.getString("type"), it.getLong("walletId"), it.stringOrNull("category"), it.getLong("date"), it.getString("status"), it.stringOrNull("transferGroupId")) }
            val products = root.optJSONArray("products").mapObjects { ProductEntity(it.getLong("id"), it.getString("name"), it.optString("description", ""), it.getLong("quantityMilli"), it.getLong("averageUnitCost"), it.optLong("suggestedSalePrice", 0L), it.getLong("createdAt"), it.getBoolean("active")) }
            val sales = root.optJSONArray("sales").mapObjects { SaleEntity(it.getLong("id"), it.getLong("transactionId"), it.longOrNull("productId"), it.getString("productName"), it.optString("description", ""), it.getLong("quantityMilli"), it.getLong("acquisitionCost"), it.getLong("saleAmount"), it.getLong("additionalCosts"), it.getLong("saleDate")) }
            val debts = root.optJSONArray("liabilities").mapObjects { LiabilityEntity(it.getLong("id"), it.getString("name"), it.getLong("initialAmount"), it.getLong("outstandingAmount"), it.longOrNull("interestRateBasisPoints")?.toInt(), it.longOrNull("dueDate"), it.getString("status")) }
            val ledgerAccounts = root.optJSONArray("ledgerAccounts").mapObjects { LedgerAccountEntity(it.getLong("id"), it.getString("code"), it.getString("name"), it.getString("type")) }
            val entries = root.optJSONArray("journalEntries").mapObjects { JournalEntryEntity(it.getLong("id"), it.longOrNull("transactionId"), it.getString("memo"), it.getLong("date"), it.getString("status")) }
            val lines = root.optJSONArray("journalLines").mapObjects { JournalLineEntity(it.getLong("id"), it.getLong("entryId"), it.getLong("accountId"), it.getLong("debit"), it.getLong("credit")) }
            Backup(wallets, txs, products, sales, debts, ledgerAccounts, entries, lines)
        } catch (e: org.json.JSONException) { throw IllegalArgumentException("El respaldo está incompleto o dañado.") }
        val walletIds = parsed.wallets.map { it.id }.toSet()
        require(parsed.transactions.all { it.walletId in walletIds }) { "El respaldo tiene movimientos sin cuenta." }
        db.withTransaction {
            dao.deleteAllJournalLines(); dao.deleteAllJournalEntries(); dao.deleteAllLedgerAccounts()
            dao.deleteAllSales(); dao.deleteAllTransactions(); dao.deleteAllProducts(); dao.deleteAllLiabilities(); dao.deleteAllWallets()
            dao.insertWallets(parsed.wallets); dao.insertTransactions(parsed.transactions); dao.insertProducts(parsed.products)
            dao.insertSales(parsed.sales); dao.insertLiabilities(parsed.liabilities); dao.insertLedgerAccounts(parsed.ledgerAccounts)
            dao.insertJournalEntries(parsed.entries); dao.insertJournalLines(parsed.lines)
        }
    }

    private class Backup(
        val wallets: List<WalletEntity>, val transactions: List<TransactionEntity>, val products: List<ProductEntity>,
        val sales: List<SaleEntity>, val liabilities: List<LiabilityEntity>, val ledgerAccounts: List<LedgerAccountEntity>,
        val entries: List<JournalEntryEntity>, val lines: List<JournalLineEntity>
    )

    /** Anula ingresos, gastos y transferencias sin dejar saldos negativos. Compras, ventas y abonos requieren ajuste manual. */
    suspend fun voidTransaction(id: Long) {
        db.withTransaction {
            val t = dao.getTransaction(id) ?: error("Movimiento no encontrado.")
            require(t.status == "POSTED") { "El movimiento ya está anulado." }
            when (t.type) {
                "INCOME" -> {
                    require((dao.getBalance(t.walletId) ?: 0L) >= t.amount) { "Anular dejaría la cuenta con saldo negativo." }
                    dao.markTransactionVoid(id); dao.markJournalVoid(id)
                }
                "EXPENSE" -> { dao.markTransactionVoid(id); dao.markJournalVoid(id) }
                "TRANSFER_OUT", "TRANSFER_IN" -> {
                    val group = t.transferGroupId ?: error("Transferencia sin grupo.")
                    val legs = dao.getTransferLegs(group).filter { it.status == "POSTED" }
                    val incoming = legs.firstOrNull { it.type == "TRANSFER_IN" } ?: error("Transferencia incompleta.")
                    require((dao.getBalance(incoming.walletId) ?: 0L) >= incoming.amount) { "Anular dejaría la cuenta destino con saldo negativo." }
                    legs.forEach { dao.markTransactionVoid(it.id); dao.markJournalVoid(it.id) }
                }
                "SALE" -> {
                    val sale = dao.getSaleByTransaction(id) ?: error("No se encontró el detalle de esta venta.")
                    val productId = sale.productId ?: error("La venta no está vinculada a un producto.")
                    val product = dao.getProduct(productId) ?: error("El producto ya no está disponible.")
                    dao.updateProduct(product.copy(quantityMilli = Math.addExact(product.quantityMilli, sale.quantityMilli)))
                    dao.markTransactionVoid(id); dao.markJournalVoid(id)
                }
                else -> throw IllegalArgumentException("Este tipo de movimiento no se puede eliminar todavía; requiere una reversión específica.")

            }
        }
    }

    suspend fun getFinancialSummary(): FinancialSummary = db.withTransaction {
        val cash = dao.observeWalletBalancesSnapshot().sumOf { it.balance }
        val inventory = dao.getInventoryValue()
        val debts = dao.getTotalLiabilities()
        FinancialSummary(cash, debts, cash + inventory - debts, dao.getTotalIncome(), dao.getTotalExpense(), inventory, dao.getSalesProfit())
    }

    suspend fun createWallet(name: String, type: String, openingBalance: Long) {
        val clean = name.trim(); require(clean.isNotEmpty()) { "Escribe un nombre para la cuenta." }
        require(openingBalance >= 0) { "El saldo inicial no puede ser negativo." }
        db.withTransaction {
            dao.insertWallet(WalletEntity(name=clean,type=type,openingBalance=openingBalance))
            if (openingBalance > 0) {
                val cash=ledger("1000","Efectivo y bancos","ASSET"); val equity=ledger("3000","Capital inicial","EQUITY")
                postJournal("Saldo inicial · $clean",null,listOf(cash to openingBalance,equity to -openingBalance))
            }
        }
    }

    suspend fun addIncome(description: String, amount: Long, walletId: Long, category: String? = null) = postCash(description,amount,walletId,"INCOME",false)
    suspend fun addExpense(description: String, amount: Long, walletId: Long, category: String? = null) = postCash(description,amount,walletId,"EXPENSE",true)

    private suspend fun postCash(description:String,amount:Long,walletId:Long,type:String,checkFunds:Boolean) {
        val memo=description.trim(); require(memo.isNotEmpty()) { "Escribe una descripción." }; require(amount>0) { "El importe debe ser mayor que cero." }
        db.withTransaction {
            require(dao.getWallet(walletId)!=null) { "La cuenta seleccionada no está disponible." }
            if(checkFunds) require((dao.getBalance(walletId)?:0L)>=amount) { "Saldo insuficiente." }
            val tx=dao.insertTransaction(TransactionEntity(description=memo,amount=amount,type=type,walletId=walletId))
            val cash=ledger("1000","Efectivo y bancos","ASSET")
            val other=if(type=="INCOME") ledger("4000","Ingresos","INCOME") else ledger("5000","Gastos","EXPENSE")
            postJournal(memo,tx,if(type=="INCOME") listOf(cash to amount,other to -amount) else listOf(other to amount,cash to -amount))
        }
    }

    suspend fun transfer(description:String,amount:Long,fromWalletId:Long,toWalletId:Long) {
        val memo=description.trim().ifEmpty { "Transferencia" }; require(amount>0) { "El importe debe ser mayor que cero." }; require(fromWalletId!=toWalletId) { "Selecciona cuentas diferentes." }
        db.withTransaction {
            require(dao.getWallet(fromWalletId)!=null && dao.getWallet(toWalletId)!=null) { "Una cuenta no está disponible." }
            require((dao.getBalance(fromWalletId)?:0L)>=amount) { "Saldo insuficiente." }
            val group=UUID.randomUUID().toString()
            val out=dao.insertTransaction(TransactionEntity(description="$memo · Salida",amount=amount,type="TRANSFER_OUT",walletId=fromWalletId,transferGroupId=group))
            dao.insertTransaction(TransactionEntity(description="$memo · Entrada",amount=amount,type="TRANSFER_IN",walletId=toWalletId,transferGroupId=group))
            val cash=ledger("1000","Efectivo y bancos","ASSET"); postJournal(memo,out,listOf(cash to amount,cash to -amount))
        }
    }

    suspend fun createProduct(name:String,description:String="",unitCost:Long=0L,salePrice:Long=0L) {
        val clean=name.trim(); require(clean.isNotEmpty()) { "Escribe el nombre del producto." }
        require(unitCost>=0 && salePrice>=0) { "Los precios no pueden ser negativos." }
        db.withTransaction { dao.insertProduct(ProductEntity(name=clean,description=description.trim(),averageUnitCost=unitCost,suggestedSalePrice=salePrice)) }
    }

    /** Compra de mercancía: costo promedio ponderado y salida de efectivo en una sola transacción. */
    suspend fun purchaseProduct(productId:Long,quantityMilli:Long,totalCost:Long,walletId:Long,description:String="Compra de mercancía") {
        require(quantityMilli>0 && totalCost>0) { "Cantidad e importe deben ser mayores que cero." }
        db.withTransaction {
            val product=dao.getProduct(productId) ?: error("Producto no encontrado.")
            require(dao.getWallet(walletId)!=null) { "Cuenta no disponible." }
            require((dao.getBalance(walletId)?:0L)>=totalCost) { "Saldo insuficiente para comprar mercancía." }
            val oldValue=Math.multiplyExact(product.quantityMilli,product.averageUnitCost)/1000L
            val newQty=Math.addExact(product.quantityMilli,quantityMilli)
            val newAverage=Math.multiplyExact(Math.addExact(oldValue,totalCost),1000L)/newQty
            dao.updateProduct(product.copy(quantityMilli=newQty,averageUnitCost=newAverage))
            val tx=dao.insertTransaction(TransactionEntity(description=description,amount=totalCost,type="PURCHASE",walletId=walletId))
            val inventory=ledger("1200","Mercancía","ASSET"); val cash=ledger("1000","Efectivo y bancos","ASSET")
            postJournal(description,tx,listOf(inventory to totalCost,cash to -totalCost))
        }
    }

    /** Venta parcial: conserva costo total histórico en la venta y descuenta existencias. */
    suspend fun sellProduct(productId:Long,quantityMilli:Long,saleAmount:Long,walletId:Long,additionalCosts:Long=0L,description:String="Venta de mercancía") {
        require(quantityMilli>0 && saleAmount>0 && additionalCosts>=0) { "Revisa cantidad, precio y gastos." }
        db.withTransaction {
            val product=dao.getProduct(productId) ?: error("Producto no encontrado.")
            require(quantityMilli<=product.quantityMilli) { "No hay existencias suficientes." }
            require(dao.getWallet(walletId)!=null) { "Cuenta receptora no disponible." }
            val cost=Math.multiplyExact(quantityMilli,product.averageUnitCost)/1000L
            val netReceived=Math.subtractExact(saleAmount,additionalCosts)
            require(netReceived>0) { "El importe neto recibido debe ser mayor que cero." }
            dao.updateProduct(product.copy(quantityMilli=product.quantityMilli-quantityMilli))
            val tx=dao.insertTransaction(TransactionEntity(description=description,amount=netReceived,type="SALE",walletId=walletId))
            dao.insertSale(SaleEntity(transactionId=tx,productId=product.id,productName=product.name,description=description,quantityMilli=quantityMilli,acquisitionCost=cost,saleAmount=saleAmount,additionalCosts=additionalCosts))
            val cash=ledger("1000","Efectivo y bancos","ASSET"); val sales=ledger("4100","Ventas","INCOME")
            val cogs=ledger("5100","Costo de mercancía vendida","EXPENSE"); val inventory=ledger("1200","Mercancía","ASSET")
            val sellingCosts=ledger("5300","Gastos de venta","EXPENSE")
            postJournal(description,tx,listOf(cash to netReceived,sellingCosts to additionalCosts,sales to -saleAmount,cogs to cost,inventory to -cost))
        }
    }

    suspend fun createLiability(name:String,amount:Long) {
        val clean=name.trim(); require(clean.isNotEmpty()) { "Escribe el nombre de la deuda." }; require(amount>0) { "El monto debe ser mayor que cero." }
        db.withTransaction {
            dao.insertLiability(LiabilityEntity(name=clean,initialAmount=amount,outstandingAmount=amount))
            val equity=ledger("3000","Capital inicial","EQUITY"); val liability=ledger("2100","Deudas","LIABILITY")
            postJournal("Registro inicial de deuda · $clean",null,listOf(equity to amount,liability to -amount))
        }
    }

    suspend fun payLiability(liabilityId:Long,walletId:Long,capital:Long,interest:Long=0L) {
        require(capital>=0 && interest>=0 && capital+interest>0) { "El pago debe ser mayor que cero." }
        db.withTransaction {
            val debt=dao.getLiability(liabilityId) ?: error("Deuda no encontrada.")
            require(debt.status=="ACTIVE") { "La deuda ya está liquidada." }
            require(capital<=debt.outstandingAmount) { "El abono supera la deuda pendiente." }
            require(dao.getWallet(walletId)!=null) { "Cuenta no disponible." }
            val total=Math.addExact(capital,interest); require((dao.getBalance(walletId)?:0L)>=total) { "Saldo insuficiente." }
            val remaining=debt.outstandingAmount-capital
            dao.updateLiability(debt.copy(outstandingAmount=remaining,status=if(remaining==0L) "PAID" else "ACTIVE"))
            val tx=dao.insertTransaction(TransactionEntity(description="Abono: ${debt.name}",amount=total,type="DEBT_PAYMENT",walletId=walletId))
            val cash=ledger("1000","Efectivo y bancos","ASSET")
            val lines=mutableListOf(cash to -total)
            if(capital>0) lines.add(ledger("2100","Deudas","LIABILITY") to capital)
            if(interest>0) lines.add(ledger("5200","Intereses","EXPENSE") to interest)
            postJournal("Abono: ${debt.name}",tx,lines)
        }
    }

    private suspend fun postJournal(memo:String,transactionId:Long?,allLines:List<Pair<Long,Long>>) {
        val lines=allLines.filter { it.second!=0L }
        require(lines.isNotEmpty() && lines.sumOf { it.second }==0L) { "Asiento contable desequilibrado." }
        val entry=dao.insertJournalEntry(JournalEntryEntity(transactionId=transactionId,memo=memo))
        dao.insertJournalLines(lines.map { (account,value)->JournalLineEntity(entryId=entry,accountId=account,debit=if(value>0)value else 0,credit=if(value<0)-value else 0) })
        check(dao.isEntryBalanced(entry)) { "No se pudo validar el asiento contable." }
    }
    private suspend fun ledger(code:String,name:String,type:String):Long = dao.getLedgerAccount(code)?.id ?: dao.insertLedgerAccount(LedgerAccountEntity(code=code,name=name,type=type))
}
