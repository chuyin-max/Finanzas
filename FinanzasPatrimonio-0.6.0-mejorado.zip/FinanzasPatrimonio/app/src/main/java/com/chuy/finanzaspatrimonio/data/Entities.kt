package com.chuy.finanzaspatrimonio.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

/** All monetary values are stored as integer centavos (MXN), never Float/Double. */
@Entity(tableName = "wallets")
data class WalletEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val type: String = "CUSTOM",
    val currency: String = "MXN",
    val openingBalance: Long = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val active: Boolean = true
)

@Entity(tableName = "transactions", indices = [Index("walletId"), Index("date"), Index("transferGroupId")])
data class TransactionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val description: String,
    val amount: Long,
    val type: String,
    val walletId: Long,
    val category: String? = null,
    val date: Long = System.currentTimeMillis(),
    val status: String = "POSTED",
    val transferGroupId: String? = null
)

@Entity(tableName = "ledger_accounts", indices = [Index(value = ["code"], unique = true)])
data class LedgerAccountEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val code: String,
    val name: String,
    val type: String
)

@Entity(tableName = "journal_entries")
data class JournalEntryEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val transactionId: Long? = null,
    val memo: String,
    val date: Long = System.currentTimeMillis(),
    val status: String = "POSTED"
)

@Entity(
    tableName = "journal_lines",
    foreignKeys = [ForeignKey(entity = JournalEntryEntity::class, parentColumns = ["id"], childColumns = ["entryId"], onDelete = ForeignKey.CASCADE)],
    indices = [Index("entryId"), Index("accountId")]
)
data class JournalLineEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val entryId: Long,
    val accountId: Long,
    val debit: Long = 0,
    val credit: Long = 0
)

@Entity(tableName = "products")
data class ProductEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val description: String = "",
    val quantityMilli: Long = 0,
    val averageUnitCost: Long = 0,
    val suggestedSalePrice: Long = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val active: Boolean = true
)

@Entity(tableName = "assets")
data class AssetEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val description: String = "",
    val acquisitionValue: Long,
    val currentValue: Long,
    val acquisitionDate: Long = System.currentTimeMillis(),
    val status: String = "ACTIVE"
)

@Entity(tableName = "liabilities")
data class LiabilityEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val initialAmount: Long,
    val outstandingAmount: Long,
    val interestRateBasisPoints: Int? = null,
    val dueDate: Long? = null,
    val status: String = "ACTIVE"
)

@Entity(
    tableName = "sales",
    foreignKeys = [ForeignKey(entity = TransactionEntity::class, parentColumns = ["id"], childColumns = ["transactionId"], onDelete = ForeignKey.RESTRICT)],
    indices = [Index("transactionId"), Index("productId")]
)
data class SaleEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val transactionId: Long,
    val productId: Long? = null,
    val productName: String,
    val description: String = "",
    val quantityMilli: Long = 1000,
    val acquisitionCost: Long,
    val saleAmount: Long,
    val additionalCosts: Long = 0,
    val saleDate: Long = System.currentTimeMillis()
) {
    /** Historical net profit snapshot: sale amount minus acquisition and associated costs. */
    val profit: Long get() = saleAmount - acquisitionCost - additionalCosts
}
