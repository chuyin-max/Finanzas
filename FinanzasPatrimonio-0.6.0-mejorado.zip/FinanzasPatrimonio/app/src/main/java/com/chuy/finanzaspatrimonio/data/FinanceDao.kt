package com.chuy.finanzaspatrimonio.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

/** Saldo calculado desde saldo inicial y movimientos confirmados. */
data class WalletBalance(
    val id: Long, val name: String, val type: String, val currency: String,
    val openingBalance: Long, val balance: Long
)

@Dao
interface FinanceDao {
    @Query("""
        SELECT w.id, w.name, w.type, w.currency, w.openingBalance,
        w.openingBalance + COALESCE(SUM(CASE
            WHEN t.type IN ('INCOME','TRANSFER_IN','SALE') THEN t.amount
            WHEN t.type IN ('EXPENSE','TRANSFER_OUT','PURCHASE','DEBT_PAYMENT') THEN -t.amount
            ELSE 0 END),0) AS balance
        FROM wallets w LEFT JOIN transactions t ON t.walletId=w.id AND t.status='POSTED'
        WHERE w.active=1 GROUP BY w.id ORDER BY w.name COLLATE NOCASE
    """)
    fun observeWalletBalances(): Flow<List<WalletBalance>>

    @Query("""
        SELECT w.id, w.name, w.type, w.currency, w.openingBalance,
        w.openingBalance + COALESCE(SUM(CASE
            WHEN t.type IN ('INCOME','TRANSFER_IN','SALE') THEN t.amount
            WHEN t.type IN ('EXPENSE','TRANSFER_OUT','PURCHASE','DEBT_PAYMENT') THEN -t.amount
            ELSE 0 END),0) AS balance
        FROM wallets w LEFT JOIN transactions t ON t.walletId=w.id AND t.status='POSTED'
        WHERE w.active=1 GROUP BY w.id
    """)
    suspend fun observeWalletBalancesSnapshot(): List<WalletBalance>

    @Query("SELECT * FROM wallets WHERE active=1 ORDER BY name COLLATE NOCASE")
    fun observeWallets(): Flow<List<WalletEntity>>
    @Query("SELECT * FROM wallets ORDER BY id") suspend fun allWalletsForBackup(): List<WalletEntity>

    @Query("SELECT * FROM transactions WHERE status='POSTED' ORDER BY date DESC,id DESC LIMIT 300")
    fun observeRecentTransactions(): Flow<List<TransactionEntity>>
    @Query("SELECT * FROM transactions ORDER BY id") suspend fun allTransactionsForBackup(): List<TransactionEntity>

    @Query("SELECT * FROM wallets WHERE id=:walletId AND active=1 LIMIT 1")
    suspend fun getWallet(walletId: Long): WalletEntity?

    @Query("""
        SELECT w.openingBalance + COALESCE(SUM(CASE
            WHEN t.type IN ('INCOME','TRANSFER_IN','SALE') THEN t.amount
            WHEN t.type IN ('EXPENSE','TRANSFER_OUT','PURCHASE','DEBT_PAYMENT') THEN -t.amount
            ELSE 0 END),0)
        FROM wallets w LEFT JOIN transactions t ON t.walletId=w.id AND t.status='POSTED'
        WHERE w.id=:walletId GROUP BY w.id
    """)
    suspend fun getBalance(walletId: Long): Long?

    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertWallet(wallet: WalletEntity): Long
    @Query("SELECT * FROM ledger_accounts WHERE code=:code LIMIT 1") suspend fun getLedgerAccount(code: String): LedgerAccountEntity?
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertLedgerAccount(account: LedgerAccountEntity): Long
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertJournalEntry(entry: JournalEntryEntity): Long
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertJournalLines(lines: List<JournalLineEntity>)
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertTransaction(transaction: TransactionEntity): Long
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertProduct(product: ProductEntity): Long
    @Update suspend fun updateProduct(product: ProductEntity)
    @Query("SELECT * FROM products WHERE active=1 ORDER BY name COLLATE NOCASE") fun observeProducts(): Flow<List<ProductEntity>>
    @Query("SELECT * FROM products ORDER BY id") suspend fun allProductsForBackup(): List<ProductEntity>
    @Query("SELECT * FROM products WHERE id=:id AND active=1 LIMIT 1") suspend fun getProduct(id: Long): ProductEntity?
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertSale(sale: SaleEntity): Long
    @Query("SELECT * FROM sales ORDER BY saleDate DESC,id DESC LIMIT 300") fun observeSales(): Flow<List<SaleEntity>>
    @Query("SELECT * FROM sales WHERE transactionId=:transactionId LIMIT 1") suspend fun getSaleByTransaction(transactionId: Long): SaleEntity?
    @Query("SELECT * FROM sales ORDER BY id") suspend fun allSalesForBackup(): List<SaleEntity>
    @Query("SELECT COALESCE(SUM(quantityMilli * averageUnitCost / 1000),0) FROM products WHERE active=1") suspend fun getInventoryValue(): Long
    @Query("SELECT COALESCE(SUM(s.saleAmount - s.acquisitionCost - s.additionalCosts),0) FROM sales s INNER JOIN transactions t ON t.id=s.transactionId WHERE t.status='POSTED'") suspend fun getSalesProfit(): Long
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertLiability(liability: LiabilityEntity): Long
    @Update suspend fun updateLiability(liability: LiabilityEntity)
    @Query("SELECT * FROM liabilities ORDER BY status DESC,name COLLATE NOCASE") fun observeLiabilities(): Flow<List<LiabilityEntity>>
    @Query("SELECT * FROM liabilities ORDER BY id") suspend fun allLiabilitiesForBackup(): List<LiabilityEntity>
    @Query("SELECT * FROM liabilities WHERE id=:id LIMIT 1") suspend fun getLiability(id: Long): LiabilityEntity?
    @Query("SELECT COALESCE(SUM(outstandingAmount),0) FROM liabilities WHERE status='ACTIVE'") suspend fun getTotalLiabilities(): Long
    @Query("SELECT COALESCE(SUM(CASE WHEN type='INCOME' THEN amount ELSE 0 END),0) FROM transactions WHERE status='POSTED'") suspend fun getTotalIncome(): Long
    @Query("SELECT COALESCE(SUM(CASE WHEN type='EXPENSE' THEN amount ELSE 0 END),0) FROM transactions WHERE status='POSTED'") suspend fun getTotalExpense(): Long
    @Query("SELECT COALESCE(SUM(debit),0) FROM journal_lines WHERE entryId=:entryId") suspend fun getEntryDebits(entryId: Long): Long
    @Query("SELECT COALESCE(SUM(credit),0) FROM journal_lines WHERE entryId=:entryId") suspend fun getEntryCredits(entryId: Long): Long
    @Query("SELECT * FROM journal_entries ORDER BY id") suspend fun observeJournalEntriesForTest(): List<JournalEntryEntity>
    @Query("SELECT COALESCE(SUM(debit),0)=COALESCE(SUM(credit),0) FROM journal_lines WHERE entryId=:entryId") suspend fun isEntryBalanced(entryId: Long): Boolean

    // --- Restauración y anulación ---
    @Query("SELECT * FROM ledger_accounts ORDER BY id") suspend fun allLedgerForBackup(): List<LedgerAccountEntity>
    @Query("SELECT * FROM journal_entries ORDER BY id") suspend fun allJournalEntriesForBackup(): List<JournalEntryEntity>
    @Query("SELECT * FROM journal_lines ORDER BY id") suspend fun allJournalLinesForBackup(): List<JournalLineEntity>
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertWallets(items: List<WalletEntity>)
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertTransactions(items: List<TransactionEntity>)
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertProducts(items: List<ProductEntity>)
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertSales(items: List<SaleEntity>)
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertLiabilities(items: List<LiabilityEntity>)
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertLedgerAccounts(items: List<LedgerAccountEntity>)
    @Insert(onConflict=OnConflictStrategy.ABORT) suspend fun insertJournalEntries(items: List<JournalEntryEntity>)
    @Query("DELETE FROM journal_lines") suspend fun deleteAllJournalLines()
    @Query("DELETE FROM journal_entries") suspend fun deleteAllJournalEntries()
    @Query("DELETE FROM ledger_accounts") suspend fun deleteAllLedgerAccounts()
    @Query("DELETE FROM sales") suspend fun deleteAllSales()
    @Query("DELETE FROM transactions") suspend fun deleteAllTransactions()
    @Query("DELETE FROM products") suspend fun deleteAllProducts()
    @Query("DELETE FROM liabilities") suspend fun deleteAllLiabilities()
    @Query("DELETE FROM wallets") suspend fun deleteAllWallets()
    @Query("SELECT * FROM transactions WHERE id=:id LIMIT 1") suspend fun getTransaction(id: Long): TransactionEntity?
    @Query("SELECT * FROM transactions WHERE transferGroupId=:group") suspend fun getTransferLegs(group: String): List<TransactionEntity>
    @Query("UPDATE transactions SET status='VOID' WHERE id=:id") suspend fun markTransactionVoid(id: Long)
    @Query("UPDATE journal_entries SET status='VOID' WHERE transactionId=:id") suspend fun markJournalVoid(id: Long)
}
