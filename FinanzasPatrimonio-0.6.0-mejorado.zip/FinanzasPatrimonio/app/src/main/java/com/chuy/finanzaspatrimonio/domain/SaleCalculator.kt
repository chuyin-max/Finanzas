package com.chuy.finanzaspatrimonio.domain

/** Monetary values are centavos. */
data class SaleResult(
    val grossSale: Long,
    val acquisitionCost: Long,
    val additionalCosts: Long,
    val netProfit: Long,
    val marginBasisPoints: Int?
)

object SaleCalculator {
    fun calculate(saleAmount: Long, acquisitionCost: Long, additionalCosts: Long): SaleResult {
        require(saleAmount >= 0) { "El precio de venta no puede ser negativo." }
        require(acquisitionCost >= 0) { "El costo de adquisición no puede ser negativo." }
        require(additionalCosts >= 0) { "Los gastos adicionales no pueden ser negativos." }
        val profit = Math.subtractExact(Math.subtractExact(saleAmount, acquisitionCost), additionalCosts)
        val margin = if (saleAmount == 0L) null else ((profit * 10_000L) / saleAmount).toInt()
        return SaleResult(saleAmount, acquisitionCost, additionalCosts, profit, margin)
    }
}
