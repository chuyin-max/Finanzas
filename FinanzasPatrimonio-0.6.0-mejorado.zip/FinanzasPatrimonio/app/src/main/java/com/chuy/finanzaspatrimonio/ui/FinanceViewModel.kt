package com.chuy.finanzaspatrimonio.ui

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.chuy.finanzaspatrimonio.data.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class FinanceViewModel(private val repository: FinanceRepository) : ViewModel() {
    private val _summary=MutableStateFlow(FinancialSummary(0,0,0,0,0))
    val summary=_summary
    val wallets=repository.wallets.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5_000),emptyList())
    val balances=repository.walletBalances.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5_000),emptyList())
    val transactions=repository.transactions.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5_000),emptyList())
    val products=repository.products.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5_000),emptyList())
    val liabilities=repository.liabilities.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5_000),emptyList())
    val sales=repository.sales.stateIn(viewModelScope,SharingStarted.WhileSubscribed(5_000),emptyList())
    var message:((String)->Unit)?=null
    init { refresh() }
    private fun refresh(){ viewModelScope.launch { runCatching { repository.getFinancialSummary() }.onSuccess { _summary.value=it } } }
    fun createWallet(name:String,type:String,balance:Long)=action { repository.createWallet(name,type,balance); "Cuenta creada." }
    fun income(description:String,amount:Long,wallet:Long)=action { repository.addIncome(description,amount,wallet); "Ingreso registrado." }
    fun expense(description:String,amount:Long,wallet:Long)=action { repository.addExpense(description,amount,wallet); "Gasto registrado." }
    fun transfer(description:String,amount:Long,from:Long,to:Long)=action { repository.transfer(description,amount,from,to); "Transferencia realizada." }
    fun createProduct(name:String,description:String,cost:Long,salePrice:Long)=action { repository.createProduct(name,description,cost,salePrice); "Producto registrado." }
    fun purchase(product:Long,qty:Long,cost:Long,wallet:Long)=action { repository.purchaseProduct(product,qty,cost,wallet); "Compra registrada y existencias actualizadas." }
    fun sell(product:Long,qty:Long,amount:Long,wallet:Long)=action { repository.sellProduct(product,qty,amount,wallet); "Venta registrada." }
    fun createDebt(name:String,amount:Long)=action { repository.createLiability(name,amount); "Deuda registrada." }
    fun payDebt(debt:Long,wallet:Long,capital:Long,interest:Long)=action { repository.payLiability(debt,wallet,capital,interest); "Abono registrado." }
    fun restore(json:String)=action { repository.importJson(json); "Respaldo restaurado." }
    fun voidTransaction(id:Long)=action { repository.voidTransaction(id); "Movimiento anulado." }
    suspend fun exportCsv():String=repository.exportCsv()
    suspend fun exportJson():String=repository.exportJson()
    private fun action(block:suspend()->String){ viewModelScope.launch { try { val result=block(); refresh(); message?.invoke(result) } catch(e:Exception){ message?.invoke(e.message?:"No se pudo guardar.") } } }
    class Factory(private val repository:FinanceRepository):ViewModelProvider.Factory { @Suppress("UNCHECKED_CAST") override fun <T:ViewModel> create(modelClass:Class<T>):T=FinanceViewModel(repository) as T }
}
