# FinanzasPatrimonio — versión 0.5.0 (sin compilar)

Aplicación Android nativa, local y offline-first para llevar un control sencillo de **efectivo, mercancía y deudas**. Moneda predeterminada: MXN.

## Alcance implementado en el código

- Kotlin, Jetpack Compose, Material 3 y tema oscuro.
- Room/SQLite para persistencia local; arquitectura MVVM.
- Cuentas monetarias múltiples con saldo inicial y saldo calculado desde movimientos.
- Ingresos, gastos y transferencias entre cuentas; no se muestran ni solicitan categorías.
- Registro de productos de mercancía.
- Compras de mercancía con actualización de existencias y costo promedio ponderado.
- Ventas parciales, validación de existencias y conservación del costo histórico de cada venta.
- Cálculo de utilidad acumulada por ventas.
- Registro de deudas y abonos que separan capital e intereses.
- Dashboard con efectivo, valor de mercancía, deudas, utilidad acumulada y patrimonio neto.
- Historial general de movimientos.
- Exportación de movimientos a CSV desde el selector de archivos de Android.
- Exportación de respaldo estructurado JSON con cuentas, movimientos, mercancía, ventas y deudas.
- Importes almacenados como `Long` en centavos.
- Operaciones que afectan varias tablas ejecutadas en transacciones Room.
- Asientos de partida doble para operaciones principales.

## Fórmulas

- Patrimonio neto = efectivo + valor contable de mercancía − deudas pendientes.
- Costo promedio ponderado = (valor previo del inventario + costo de nueva compra) / existencias resultantes.
- Utilidad de venta = importe recibido − costo histórico de mercancía vendida − gastos adicionales.
- Las transferencias no alteran el efectivo consolidado.
- Los abonos a capital reducen el pasivo; los intereses son gasto.

## Estructura

- `data/Entities.kt`: entidades Room existentes.
- `data/FinanceDao.kt`: consultas de cuentas, mercancía, ventas y deudas.
- `data/FinanceRepository.kt`: reglas financieras y transacciones atómicas.
- `data/AppDatabase.kt`: base Room, esquema versión 2.
- `data/DatabaseProvider.kt`: instancia y migración 1→2.
- `ui/FinanceViewModel.kt`: estado y acciones.
- `MainActivity.kt`: dashboard, efectivo, mercancía, deudas e historial.
- `src/androidTest/.../FinanceRepositoryTest.kt`: pruebas instrumentadas existentes y nuevas pruebas de inventario/ventas/deudas.

## Abrir y compilar

1. Abrir la carpeta raíz en Android Studio.
2. Usar JDK 17 y Android SDK Platform 36.
3. Usar Gradle 8.13 o una versión compatible con Android Gradle Plugin 8.13.2; el proyecto aún no incluye Gradle Wrapper. Sincronizar Gradle con internet.
4. Ejecutar las pruebas instrumentadas en un emulador o dispositivo.
5. Generar APK con `./gradlew assembleDebug`.

El APK debug, si la compilación termina correctamente, se genera en `app/build/outputs/apk/debug/app-debug.apk`.

## Estado de verificación de esta entrega

Esta entrega contiene cambios de código y pruebas nuevas, pero en el entorno de preparación no se encontró Gradle instalado ni `ANDROID_HOME` configurado. Por tanto, **no se ha ejecutado la compilación Android, no se ha ejecutado el conjunto de pruebas y no se ha generado un APK verificado**. La integridad del ZIP se comprueba por separado y no equivale a una compilación correcta.

## Pendiente

- Ejecutar compilación, lint y pruebas instrumentadas en Android Studio/CI.
- Implementar restauración/importación del respaldo JSON (esta versión solo exporta).
- Añadir edición/archivo de cuentas y productos, y flujo formal de reversos/correcciones.
- Probar restauración y migraciones en dispositivos con datos reales.

## Cambios en 0.5.0 (revisión estática)

- Restauración de respaldo JSON (formato v2, todo o nada) desde Historial.
- Anulación de ingresos, gastos y transferencias (toca el movimiento en Historial).
- Intereses ahora usan la cuenta contable 5200; antes colisionaba con 5100.
- Ventas registran ingreso bruto y gastos de venta (5300) en el asiento.
- Asientos ignoran líneas en cero en lugar de fallar.
- Se quitó `jvmToolchain(17)`: fallaba con el JDK 21 de Android Studio.
- Se agregó `.github/workflows/build-apk.yml` para generar el APK en GitHub Actions.
- Nuevas pruebas: anulación, ida y vuelta de respaldo, respaldo inválido.
