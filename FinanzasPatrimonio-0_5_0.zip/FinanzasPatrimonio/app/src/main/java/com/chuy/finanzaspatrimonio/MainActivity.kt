package com.chuy.finanzaspatrimonio

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.viewModels
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalanceWallet
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.MoneyOff
import androidx.compose.material.icons.filled.SwapHoriz
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.chuy.finanzaspatrimonio.data.*
import com.chuy.finanzaspatrimonio.ui.FinanceViewModel
import java.math.BigDecimal
import java.math.RoundingMode
import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity:ComponentActivity(){
    private val vm:FinanceViewModel by viewModels { FinanceViewModel.Factory(FinanceRepository(DatabaseProvider.get(applicationContext))) }
    override fun onCreate(savedInstanceState:Bundle?){super.onCreate(savedInstanceState);setContent { FinanceApp(vm) }}
}

private val bg=Color(0xFF101114); private val panel=Color(0xFF1B1D22); private val accent=Color(0xFFB7A4FF); private val muted=Color(0xFF9A9CA5)
private val moneyFmt=NumberFormat.getCurrencyInstance(Locale("es","MX"))
private fun money(cents:Long)=moneyFmt.format(BigDecimal.valueOf(cents,2))
private fun parseMoney(s:String):Long?=try{BigDecimal(s.trim().replace(",","")).setScale(2,RoundingMode.UNNECESSARY).movePointRight(2).longValueExact().takeIf{it>=0}}catch(_:Exception){null}
private fun parseQty(s:String):Long?=try{BigDecimal(s.trim().replace(",","")).setScale(3,RoundingMode.UNNECESSARY).movePointRight(3).longValueExact().takeIf{it>0}}catch(_:Exception){null}
private fun qty(v:Long)=BigDecimal.valueOf(v,3).stripTrailingZeros().toPlainString()
private fun date(v:Long)=SimpleDateFormat("dd/MM/yyyy · HH:mm",Locale("es","MX")).format(Date(v))

@Composable private fun FinanceApp(vm:FinanceViewModel){
    var tab by remember{mutableIntStateOf(0)}; var notice by remember{mutableStateOf("")}; var dialog by remember{mutableStateOf("")}; var moveType by remember{mutableStateOf("INCOME")}; var voidTarget by remember{mutableStateOf<TransactionEntity?>(null)}; var restoreUri by remember{mutableStateOf<android.net.Uri?>(null)}
    val balances by vm.balances.collectAsState(); val transactions by vm.transactions.collectAsState(); val products by vm.products.collectAsState(); val debts by vm.liabilities.collectAsState(); val summary by vm.summary.collectAsState()
    val snackbar= remember{SnackbarHostState()}; vm.message={notice=it}; LaunchedEffect(notice){if(notice.isNotBlank()){snackbar.showSnackbar(notice);notice=""}}
    val context= LocalContext.current; val scope= rememberCoroutineScope()
    val csvLauncher=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/csv")){uri->if(uri!=null)scope.launch{runCatching{context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use{it.write(vm.exportCsv())}?:error("No se pudo crear el archivo.")}.onSuccess{notice="CSV exportado."}.onFailure{notice=it.message?:"Error al exportar CSV."}}}
    val jsonLauncher=rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")){uri->if(uri!=null)scope.launch{runCatching{context.contentResolver.openOutputStream(uri)?.bufferedWriter()?.use{it.write(vm.exportJson())}?:error("No se pudo crear el archivo.")}.onSuccess{notice="Respaldo JSON exportado."}.onFailure{notice=it.message?:"Error al exportar respaldo."}}}
    val restoreLauncher=rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()){uri->if(uri!=null)restoreUri=uri}
    MaterialTheme(colorScheme=darkColorScheme(primary=accent,background=bg,surface=panel,onSurface=Color.White,onBackground=Color.White)){
        Scaffold(containerColor=bg,snackbarHost={SnackbarHost(snackbar)},bottomBar={
            NavigationBar(containerColor=panel){
                val labels=listOf("Inicio","Efectivo","Mercancía","Deudas","Historial"); val icons=listOf(Icons.Default.Home,Icons.Default.AccountBalanceWallet,Icons.Default.Inventory2,Icons.Default.MoneyOff,Icons.Default.History)
                labels.forEachIndexed{i,label->NavigationBarItem(selected=tab==i,onClick={tab=i},icon={Icon(icons[i],label)},label={Text(label,fontSize=10.sp)})}
            }
        },floatingActionButton={
            if(tab in 1..3) FloatingActionButton(onClick={dialog=when(tab){1->"wallet";2->"product";else->"debt"}},containerColor=accent,contentColor=bg){Text("+",fontSize=24.sp)}
        }){padding->
            when(tab){
                0->Dashboard(summary,balances,transactions,Modifier.padding(padding),onIncome={moveType="INCOME";dialog="movement"},onExpense={moveType="EXPENSE";dialog="movement"},onTransfer={moveType="TRANSFER";dialog="movement"})
                1->WalletScreen(balances,Modifier.padding(padding),onAdd={dialog="wallet"},onIncome={moveType="INCOME";dialog="movement"},onExpense={moveType="EXPENSE";dialog="movement"},onTransfer={moveType="TRANSFER";dialog="movement"})
                2->InventoryScreen(products,balances,Modifier.padding(padding),onAdd={dialog="product"},onPurchase={dialog="purchase"},onSell={dialog="sell"})
                3->DebtScreen(debts,Modifier.padding(padding),onAdd={dialog="debt"},onPay={dialog="pay"})
                else->HistoryScreen(transactions,Modifier.padding(padding),onCsv={csvLauncher.launch("FinanzasPatrimonio-movimientos.csv")},onJson={jsonLauncher.launch("FinanzasPatrimonio-respaldo.json")},onRestore={restoreLauncher.launch(arrayOf("application/json","text/plain","application/octet-stream"))},onVoid={voidTarget=it})
            }
        }
    }
    when(dialog){
        "wallet"->WalletDialog({dialog=""}){n,t,b->vm.createWallet(n,t,b);dialog=""}
        "movement"->MovementDialog(moveType,balances,{dialog=""}){type,desc,amount,a,b->when(type){"INCOME"->vm.income(desc,amount,a);"EXPENSE"->vm.expense(desc,amount,a);else->vm.transfer(desc,amount,a,b)};dialog=""}
        "product"->ProductDialog({dialog=""}){n,d->vm.createProduct(n,d);dialog=""}
        "purchase"->ProductOperationDialog("Comprar mercancía",products,balances,false,{dialog=""}){p,q,a,w->vm.purchase(p,q,a,w);dialog=""}
        "sell"->ProductOperationDialog("Vender mercancía",products,balances,true,{dialog=""}){p,q,a,w->vm.sell(p,q,a,w);dialog=""}
        "debt"->DebtDialog({dialog=""}){n,a->vm.createDebt(n,a);dialog=""}
        "pay"->PayDebtDialog(debts,balances,{dialog=""}){d,w,c,i->vm.payDebt(d,w,c,i);dialog=""}
    }
    voidTarget?.let{t->AlertDialog(onDismissRequest={voidTarget=null},title={Text("Anular movimiento")},text={Text("¿Anular \"${t.description}\" por ${money(t.amount)}? Dejará de contar en saldos y patrimonio.")},confirmButton={TextButton(onClick={vm.voidTransaction(t.id);voidTarget=null}){Text("Anular")}},dismissButton={TextButton(onClick={voidTarget=null}){Text("Cancelar")}})}
    restoreUri?.let{uri->AlertDialog(onDismissRequest={restoreUri=null},title={Text("Restaurar respaldo")},text={Text("Esto reemplaza TODOS los datos actuales con los del archivo. No se puede deshacer.")},confirmButton={TextButton(onClick={restoreUri=null;scope.launch{runCatching{withContext(Dispatchers.IO){context.contentResolver.openInputStream(uri)?.bufferedReader()?.use{it.readText()}?:error("No se pudo leer el archivo.")}}.onSuccess{vm.restore(it)}.onFailure{notice=it.message?:"Error al leer el respaldo."}}}){Text("Restaurar")}},dismissButton={TextButton(onClick={restoreUri=null}){Text("Cancelar")}})}
}

@Composable private fun Page(title:String,subtitle:String?=null,content:@Composable ColumnScope.()->Unit){Column(Modifier.fillMaxSize().padding(20.dp),verticalArrangement=Arrangement.spacedBy(14.dp)){Text(title,fontSize=25.sp,fontWeight=FontWeight.Bold,color=Color.White);if(subtitle!=null)Text(subtitle,color=muted,fontSize=13.sp);content()}}
@Composable private fun StatCard(label:String,value:Long,description:String?=null){Card(colors=CardDefaults.cardColors(containerColor=panel),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text(label,color=muted,fontSize=13.sp);Text(money(value),fontSize=23.sp,fontWeight=FontWeight.Bold,color=Color.White);if(description!=null)Text(description,color=muted,fontSize=11.sp)}}}
@Composable private fun Dashboard(s:FinancialSummary,wallets:List<WalletBalance>,txs:List<TransactionEntity>,modifier:Modifier,onIncome:()->Unit,onExpense:()->Unit,onTransfer:()->Unit){
    LazyColumn(modifier.fillMaxSize(),contentPadding=PaddingValues(18.dp),verticalArrangement=Arrangement.spacedBy(13.dp)){
        item{Text("FINANZAS PATRIMONIO",color=muted,fontSize=11.sp,letterSpacing=2.sp);Text("Resumen",color=Color.White,fontSize=27.sp,fontWeight=FontWeight.Bold)}
        item{Card(colors=CardDefaults.cardColors(containerColor=panel)){Column(Modifier.padding(20.dp)){Text("Patrimonio neto",color=muted);Text(money(s.netWorth),fontSize=32.sp,fontWeight=FontWeight.Bold,color=Color.White);Text("Efectivo + mercancía − deudas",color=muted,fontSize=12.sp)}}}
        item{Row(horizontalArrangement=Arrangement.spacedBy(10.dp)){Box(Modifier.weight(1f)){StatCard("Efectivo",s.cash)};Box(Modifier.weight(1f)){StatCard("Mercancía",s.inventory)}}}
        item{StatCard("Deudas pendientes",s.liabilities)}
        item{StatCard("Utilidad acumulada en ventas",s.salesProfit)}
        item{Text("Acciones rápidas",color=Color.White,fontWeight=FontWeight.SemiBold)}
        item{Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick=onIncome,modifier=Modifier.weight(1f)){Text("Ingreso")};Button(onClick=onExpense,modifier=Modifier.weight(1f)){Text("Gasto")};OutlinedButton(onClick=onTransfer,modifier=Modifier.weight(1f)){Text("Transferir")}}}
        item{Text("Cuentas",color=Color.White,fontWeight=FontWeight.SemiBold)}
        if(wallets.isEmpty())item{Empty("Aún no tienes cuentas. Crea una desde Efectivo.")} else items(wallets){WalletRow(it)}
        item{Text("Movimientos recientes",color=Color.White,fontWeight=FontWeight.SemiBold)}
        if(txs.isEmpty())item{Empty("Todavía no hay movimientos.")} else items(txs.take(5)){TransactionRow(it)}
    }
}
@Composable private fun WalletScreen(wallets:List<WalletBalance>,modifier:Modifier,onAdd:()->Unit,onIncome:()->Unit,onExpense:()->Unit,onTransfer:()->Unit){Column(modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("Efectivo",fontSize=26.sp,fontWeight=FontWeight.Bold);Text("Administra tus cuentas y saldos.",color=muted);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick=onIncome){Text("Ingreso")};Button(onClick=onExpense){Text("Gasto")};OutlinedButton(onClick=onTransfer){Text("Transferir")}};OutlinedButton(onClick=onAdd,modifier=Modifier.fillMaxWidth()){Text("+ Nueva cuenta")};if(wallets.isEmpty())Empty("No hay cuentas registradas.") else LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(wallets){WalletRow(it)}}}}
@Composable private fun WalletRow(w:WalletBalance){Card(colors=CardDefaults.cardColors(containerColor=panel),modifier=Modifier.fillMaxWidth()){Row(Modifier.padding(16.dp),horizontalArrangement=Arrangement.SpaceBetween,verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(w.name,color=Color.White,fontWeight=FontWeight.SemiBold);Text(w.type.replace('_',' '),color=muted,fontSize=11.sp)};Text(money(w.balance),color=Color.White,fontWeight=FontWeight.Bold)}}}
@Composable private fun InventoryScreen(products:List<ProductEntity>,wallets:List<WalletBalance>,modifier:Modifier,onAdd:()->Unit,onPurchase:()->Unit,onSell:()->Unit){Column(modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("Mercancía",fontSize=26.sp,fontWeight=FontWeight.Bold);Text("Productos, existencias y costo promedio.",color=muted);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){Button(onClick=onPurchase,enabled=products.isNotEmpty()&&wallets.isNotEmpty(),modifier=Modifier.weight(1f)){Text("Comprar")};Button(onClick=onSell,enabled=products.any{it.quantityMilli>0}&&wallets.isNotEmpty(),modifier=Modifier.weight(1f)){Text("Vender")}};OutlinedButton(onClick=onAdd,modifier=Modifier.fillMaxWidth()){Text("+ Nuevo producto")};if(products.isEmpty())Empty("Registra tu primer producto.") else LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(products){p->Card(colors=CardDefaults.cardColors(containerColor=panel),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(15.dp),verticalArrangement=Arrangement.spacedBy(4.dp)){Text(p.name,color=Color.White,fontWeight=FontWeight.Bold);if(p.description.isNotBlank())Text(p.description,color=muted,fontSize=12.sp);Row(Modifier.fillMaxWidth(),horizontalArrangement=Arrangement.SpaceBetween){Text("Existencias: ${qty(p.quantityMilli)}",color=muted);Text("Costo prom.: ${money(p.averageUnitCost)}",color=Color.White)};Text("Valor en inventario: ${money(p.quantityMilli*p.averageUnitCost/1000)}",color=accent,fontWeight=FontWeight.SemiBold)}}}}}}
@Composable private fun DebtScreen(debts:List<LiabilityEntity>,modifier:Modifier,onAdd:()->Unit,onPay:()->Unit){Column(modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("Deudas",fontSize=26.sp,fontWeight=FontWeight.Bold);Text("Controla lo pendiente y registra tus abonos.",color=muted);Button(onClick=onPay,enabled=debts.any{it.status=="ACTIVE"},modifier=Modifier.fillMaxWidth()){Text("Registrar abono")};OutlinedButton(onClick=onAdd,modifier=Modifier.fillMaxWidth()){Text("+ Nueva deuda")};if(debts.isEmpty())Empty("No tienes deudas registradas.") else LazyColumn(verticalArrangement=Arrangement.spacedBy(10.dp)){items(debts){d->Card(colors=CardDefaults.cardColors(containerColor=panel),modifier=Modifier.fillMaxWidth()){Column(Modifier.padding(16.dp)){Text(d.name,color=Color.White,fontWeight=FontWeight.Bold);Text("Saldo inicial: ${money(d.initialAmount)}",color=muted,fontSize=12.sp);Text("Pendiente: ${money(d.outstandingAmount)}",color=accent,fontWeight=FontWeight.SemiBold);Text(if(d.status=="PAID")"Liquidada" else "Activa",color=muted,fontSize=11.sp)}}}}}}
@Composable private fun HistoryScreen(txs:List<TransactionEntity>,modifier:Modifier,onCsv:()->Unit,onJson:()->Unit,onRestore:()->Unit,onVoid:(TransactionEntity)->Unit){Column(modifier.fillMaxSize().padding(18.dp),verticalArrangement=Arrangement.spacedBy(12.dp)){Text("Historial",fontSize=26.sp,fontWeight=FontWeight.Bold);Text("Movimientos registrados recientemente.",color=muted);Row(horizontalArrangement=Arrangement.spacedBy(8.dp)){OutlinedButton(onClick=onCsv,modifier=Modifier.weight(1f)){Text("Exportar CSV")};Button(onClick=onJson,modifier=Modifier.weight(1f)){Text("Respaldo JSON")}};OutlinedButton(onClick=onRestore,modifier=Modifier.fillMaxWidth()){Text("Restaurar respaldo")};Text("Toca un movimiento para anularlo.",color=muted,fontSize=11.sp);if(txs.isEmpty())Empty("No hay movimientos todavía.") else LazyColumn(verticalArrangement=Arrangement.spacedBy(8.dp)){items(txs){t->TransactionRow(t,onClick={onVoid(t)})}}}}
@Composable private fun TransactionRow(t:TransactionEntity,onClick:(()->Unit)?=null){val positive=t.type in listOf("INCOME","TRANSFER_IN","SALE");val label=when(t.type){"INCOME"->"Ingreso";"EXPENSE"->"Gasto";"TRANSFER_IN"->"Transferencia recibida";"TRANSFER_OUT"->"Transferencia enviada";"PURCHASE"->"Compra de mercancía";"SALE"->"Venta";"DEBT_PAYMENT"->"Abono a deuda";else->t.type};Card(colors=CardDefaults.cardColors(containerColor=panel),modifier=Modifier.fillMaxWidth().let{m->if(onClick!=null)m.clickable(onClick=onClick) else m}){Row(Modifier.padding(13.dp),verticalAlignment=Alignment.CenterVertically){Column(Modifier.weight(1f)){Text(t.description,color=Color.White,fontWeight=FontWeight.Medium);Text("$label · ${date(t.date)}",color=muted,fontSize=10.sp)};Text((if(positive)"+" else "−")+money(t.amount),color=if(positive)Color(0xFF8DD8A8) else Color.White,fontWeight=FontWeight.SemiBold)}}}
@Composable private fun Empty(text:String){Card(colors=CardDefaults.cardColors(containerColor=panel),modifier=Modifier.fillMaxWidth()){Box(Modifier.padding(20.dp).fillMaxWidth(),contentAlignment=Alignment.Center){Text(text,color=muted)}}}

@Composable private fun DialogFrame(title:String,onDismiss:()->Unit,content:@Composable ColumnScope.()->Unit,save:()->Unit){AlertDialog(onDismissRequest=onDismiss,title={Text(title)},text={Column(Modifier.verticalScroll(rememberScrollState()),verticalArrangement=Arrangement.spacedBy(9.dp),content=content)},confirmButton={TextButton(onClick=save){Text("Guardar")}},dismissButton={TextButton(onClick=onDismiss){Text("Cancelar")}})}
@Composable private fun WalletDialog(close:()->Unit,save:(String,String,Long)->Unit){var name by remember{mutableStateOf("")};var type by remember{mutableStateOf("Efectivo")};var balance by remember{mutableStateOf("0.00")};var error by remember{mutableStateOf("")};DialogFrame("Nueva cuenta",close,{OutlinedTextField(name,{name=it},label={Text("Nombre")},singleLine=true);OutlinedTextField(balance,{balance=it},label={Text("Saldo inicial MXN")},singleLine=true);Text("Tipo de cuenta",color=muted);Row(verticalAlignment=Alignment.CenterVertically){listOf("Efectivo","Banco","Ahorro").forEach{TextButton(onClick={type=it}){Text(if(type==it)"✓ $it" else it)}}};if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}){val v=parseMoney(balance);if(name.isBlank()||v==null)error="Revisa el nombre y el saldo." else save(name,type.uppercase(),v)}}
@Composable private fun MovementDialog(initial:String,wallets:List<WalletBalance>,close:()->Unit,save:(String,String,Long,Long,Long)->Unit){var type by remember{mutableStateOf(initial)};var desc by remember{mutableStateOf("")};var amount by remember{mutableStateOf("")};var from by remember{mutableLongStateOf(wallets.firstOrNull()?.id?:0L)};var to by remember{mutableLongStateOf(wallets.getOrNull(1)?.id?:0L)};var error by remember{mutableStateOf("")};DialogFrame("Movimiento",close,{Row{listOf("INCOME" to "Ingreso","EXPENSE" to "Gasto","TRANSFER" to "Transferir").forEach{(v,l)->TextButton(onClick={type=v}){Text(if(type==v)"• $l" else l)}}};OutlinedTextField(desc,{desc=it},label={Text("Descripción")});OutlinedTextField(amount,{amount=it},label={Text("Importe MXN")});Text("Cuenta",color=muted);wallets.forEach{w->Row(verticalAlignment=Alignment.CenterVertically){RadioButton(from==w.id,{from=w.id});Text("${w.name} · ${money(w.balance)}",color=Color.White)}};if(type=="TRANSFER"){Text("Cuenta destino",color=muted);wallets.filter{it.id!=from}.forEach{w->Row(verticalAlignment=Alignment.CenterVertically){RadioButton(to==w.id,{to=w.id});Text(w.name,color=Color.White)}}};if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}){val v=parseMoney(amount);if(wallets.isEmpty()||v==null||v<=0|| (type=="TRANSFER"&&(to==0L||to==from)))error="Completa los datos y selecciona cuentas válidas." else save(type,desc.ifBlank{if(type=="INCOME")"Ingreso" else if(type=="EXPENSE")"Gasto" else "Transferencia"},v,from,to)}}
@Composable private fun ProductDialog(close:()->Unit,save:(String,String)->Unit){var name by remember{mutableStateOf("")};var desc by remember{mutableStateOf("")};var error by remember{mutableStateOf("")};DialogFrame("Nuevo producto",close,{OutlinedTextField(name,{name=it},label={Text("Nombre del producto")});OutlinedTextField(desc,{desc=it},label={Text("Descripción (opcional)")});if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}){if(name.isBlank())error="Escribe el nombre." else save(name,desc)}}
@Composable private fun ProductOperationDialog(title:String,products:List<ProductEntity>,wallets:List<WalletBalance>,sell:Boolean,close:()->Unit,save:(Long,Long,Long,Long)->Unit){var productId by remember{mutableLongStateOf(products.firstOrNull()?.id?:0L)};var walletId by remember{mutableLongStateOf(wallets.firstOrNull()?.id?:0L)};var quantity by remember{mutableStateOf("1")};var amount by remember{mutableStateOf("")};var error by remember{mutableStateOf("")};DialogFrame(title,close,{products.forEach{p->Row(verticalAlignment=Alignment.CenterVertically){RadioButton(productId==p.id,{productId=p.id});Text("${p.name} · disp. ${qty(p.quantityMilli)}",color=Color.White)}};OutlinedTextField(quantity,{quantity=it},label={Text("Cantidad")});OutlinedTextField(amount,{amount=it},label={Text(if(sell)"Precio total de venta MXN" else "Costo total de compra MXN")});Text("Cuenta ${if(sell)"receptora" else "de pago"}",color=muted);wallets.forEach{w->Row(verticalAlignment=Alignment.CenterVertically){RadioButton(walletId==w.id,{walletId=w.id});Text(w.name,color=Color.White)}};if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}){val q=parseQty(quantity);val a=parseMoney(amount);if(productId==0L||walletId==0L||q==null||a==null||a<=0)error="Completa todos los campos." else save(productId,q,a,walletId)}}
@Composable private fun DebtDialog(close:()->Unit,save:(String,Long)->Unit){var name by remember{mutableStateOf("")};var amount by remember{mutableStateOf("")};var error by remember{mutableStateOf("")};DialogFrame("Nueva deuda",close,{OutlinedTextField(name,{name=it},label={Text("A quién / concepto")});OutlinedTextField(amount,{amount=it},label={Text("Monto pendiente MXN")});if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}){val v=parseMoney(amount);if(name.isBlank()||v==null||v<=0)error="Revisa el nombre y el monto." else save(name,v)}}
@Composable private fun PayDebtDialog(debts:List<LiabilityEntity>,wallets:List<WalletBalance>,close:()->Unit,save:(Long,Long,Long,Long)->Unit){var debtId by remember{mutableLongStateOf(debts.firstOrNull{it.status=="ACTIVE"}?.id?:0L)};var walletId by remember{mutableLongStateOf(wallets.firstOrNull()?.id?:0L)};var capital by remember{mutableStateOf("")};var interest by remember{mutableStateOf("0.00")};var error by remember{mutableStateOf("")};DialogFrame("Abonar a deuda",close,{debts.filter{it.status=="ACTIVE"}.forEach{d->Row(verticalAlignment=Alignment.CenterVertically){RadioButton(debtId==d.id,{debtId=d.id});Text("${d.name} · ${money(d.outstandingAmount)}",color=Color.White)}};Text("Cuenta de pago",color=muted);wallets.forEach{w->Row(verticalAlignment=Alignment.CenterVertically){RadioButton(walletId==w.id,{walletId=w.id});Text(w.name,color=Color.White)}};OutlinedTextField(capital,{capital=it},label={Text("Abono a capital MXN")});OutlinedTextField(interest,{interest=it},label={Text("Intereses MXN")});if(error.isNotBlank())Text(error,color=MaterialTheme.colorScheme.error)}){val c=parseMoney(capital);val i=parseMoney(interest);if(debtId==0L||walletId==0L||c==null||i==null||c+i<=0)error="Completa los datos." else save(debtId,walletId,c,i)}}
